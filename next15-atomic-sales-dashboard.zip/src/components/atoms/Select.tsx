"use client";
import { SelectHTMLAttributes } from "react";
import clsx from "clsx";

export default function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={clsx("select", props.className)} />;
}
