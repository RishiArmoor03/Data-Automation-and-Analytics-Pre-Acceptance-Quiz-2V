export default function DashboardTemplate({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-6">
      <div className="card p-6">
        <h2 className="text-2xl font-bold">{title}</h2>
        {subtitle && <p className="text-white/80 mt-1">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}
