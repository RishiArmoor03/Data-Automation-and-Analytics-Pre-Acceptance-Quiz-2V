"use client";
import Select from "@/components/atoms/Select";

export default function YearSelect({
  years,
  value,
  onChange,
}: {
  years: number[];
  value: number;
  onChange: (y: number) => void;
}) {
  return (
    <label className="flex items-center gap-2">
      <span className="text-white/80">Year</span>
      <Select
        value={String(value)}
        onChange={(e) => onChange(Number(e.target.value))}
      >
        {years.map((y) => (
          <option key={y} value={y}>
            {y}
          </option>
        ))}
      </Select>
    </label>
  );
}
