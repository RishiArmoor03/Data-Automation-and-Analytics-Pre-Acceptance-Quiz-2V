"use client";
import Input from "@/components/atoms/Input";

export default function ThresholdFilter({
  value,
  onChange,
}: {
  value: number;
  onChange: (n: number) => void;
}) {
  return (
    <label className="flex items-center gap-2">
      <span className="text-white/80">Min sales threshold</span>
      <Input
        type="number"
        min={0}
        value={Number.isNaN(value) ? "" : value}
        placeholder="e.g. 5000"
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-36"
      />
    </label>
  );
}
