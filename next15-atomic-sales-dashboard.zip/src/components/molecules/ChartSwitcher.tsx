"use client";
import Button from "@/components/atoms/Button";

export type ChartType = "bar" | "line" | "pie";

export default function ChartSwitcher({
  value,
  onChange,
}: {
  value: ChartType;
  onChange: (t: ChartType) => void;
}) {
  const tabs: ChartType[] = ["bar", "line", "pie"];
  return (
    <div className="flex gap-2">
      {tabs.map((t) => {
        const label = t.charAt(0).toUpperCase() + t.slice(1);
        const active = value === t;
        return (
          <Button
            key={t}
            variant={active ? "primary" : "ghost"}
            onClick={() => onChange(t)}
            aria-pressed={active}
          >
            {label}
          </Button>
        );
      })}
    </div>
  );
}
