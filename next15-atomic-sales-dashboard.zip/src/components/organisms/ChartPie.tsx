"use client";
import { PieChart, Pie, Tooltip, ResponsiveContainer, Cell, Legend } from "recharts";

export default function ChartPie({ data }: { data: any[] }) {
  return (
    <div className="card p-4 h-[360px]">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="sales"
            nameKey="month"
            label
            outerRadius={120}
          >
            {data.map((_, idx) => (
              <Cell key={idx} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
