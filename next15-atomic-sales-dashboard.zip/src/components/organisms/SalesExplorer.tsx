"use client";

import { useMemo, useState } from "react";
import dynamic from "next/dynamic";
import YearSelect from "@/components/molecules/YearSelect";
import ThresholdFilter from "@/components/molecules/ThresholdFilter";
import ChartSwitcher, { ChartType } from "@/components/molecules/ChartSwitcher";
import { salesByYear, availableYears } from "@/data/sales";

const ChartBar = dynamic(() => import("./ChartBar"), { ssr: false });
const ChartLine = dynamic(() => import("./ChartLine"), { ssr: false });
const ChartPie = dynamic(() => import("./ChartPie"), { ssr: false });

export default function SalesExplorer() {
  const years = availableYears();
  const [year, setYear] = useState<number>(years[years.length - 1]);
  const [threshold, setThreshold] = useState<number>(0);
  const [type, setType] = useState<ChartType>("bar");

  const data = useMemo(() => {
    const base = salesByYear(year);
    return base.filter((d) => d.sales >= threshold);
  }, [year, threshold]);

  return (
    <section className="space-y-4">
      <div className="card p-4 flex flex-wrap items-center gap-3">
        <YearSelect years={years} value={year} onChange={setYear} />
        <ThresholdFilter value={threshold} onChange={setThreshold} />
        <div className="grow" />
        <ChartSwitcher value={type} onChange={setType} />
      </div>

      {type === "bar" && <ChartBar data={data} />}
      {type === "line" && <ChartLine data={data} />}
      {type === "pie" && <ChartPie data={data} />}

      <div className="card p-4 text-sm text-white/80">
        <p>
          Data source: mock dataset inspired by typical Kaggle sales CSV structure (year, month, sales).
          You can swap to the built-in API at <code>/api/sales</code> by fetching in this component.
        </p>
      </div>
    </section>
  );
}
