export type SaleRow = { year: number; month: string; sales: number };

const months = [
  "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"
];

// Hard-coded mock data resembling a Kaggle-like shape
const rows: SaleRow[] = [
  // 2022
  {year:2022,month:"Jan",sales:8200},{year:2022,month:"Feb",sales:7900},{year:2022,month:"Mar",sales:9100},
  {year:2022,month:"Apr",sales:8700},{year:2022,month:"May",sales:9300},{year:2022,month:"Jun",sales:9600},
  {year:2022,month:"Jul",sales:9400},{year:2022,month:"Aug",sales:9800},{year:2022,month:"Sep",sales:10050},
  {year:2022,month:"Oct",sales:10400},{year:2022,month:"Nov",sales:11000},{year:2022,month:"Dec",sales:12300},
  // 2023
  {year:2023,month:"Jan",sales:10200},{year:2023,month:"Feb",sales:9800},{year:2023,month:"Mar",sales:11200},
  {year:2023,month:"Apr",sales:10800},{year:2023,month:"May",sales:11500},{year:2023,month:"Jun",sales:11900},
  {year:2023,month:"Jul",sales:11800},{year:2023,month:"Aug",sales:12100},{year:2023,month:"Sep",sales:12500},
  {year:2023,month:"Oct",sales:13000},{year:2023,month:"Nov",sales:13600},{year:2023,month:"Dec",sales:14900},
  // 2024
  {year:2024,month:"Jan",sales:13100},{year:2024,month:"Feb",sales:12500},{year:2024,month:"Mar",sales:14000},
  {year:2024,month:"Apr",sales:14400},{year:2024,month:"May",sales:15100},{year:2024,month:"Jun",sales:15500},
  {year:2024,month:"Jul",sales:15900},{year:2024,month:"Aug",sales:16200},{year:2024,month:"Sep",sales:16800},
  {year:2024,month:"Oct",sales:17300},{year:2024,month:"Nov",sales:18100},{year:2024,month:"Dec",sales:19400},
];

export function availableYears(): number[] {
  return Array.from(new Set(rows.map(r => r.year))).sort();
}

export function salesByYear(year: number): SaleRow[] {
  return rows.filter(r => r.year === year);
}
