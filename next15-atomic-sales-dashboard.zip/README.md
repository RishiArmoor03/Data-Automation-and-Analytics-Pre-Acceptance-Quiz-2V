# Atomic Sales Dashboard (Next.js 15 + TypeScript + Tailwind + Recharts)

A basic website built with **Next.js 15**, **TypeScript**, and **Tailwind CSS**, organized using the **Atomic Design** principle.
It visualizes **mock sales data** for **2022, 2023, and 2024** with multiple chart types (Bar, Line, Pie) using **Recharts**.
Includes:
- Custom threshold filter
- Chart type switcher
- Year selector
- API route you can swap in for real data later

> **Why atomic structure?**
> We separate UI into **atoms** (Input, Button), **molecules** (ChartSwitcher, ThresholdFilter, YearSelect),
> **organisms** (charts, SalesExplorer), and **templates** (Dashboard shell). This keeps components small, reusable,
> and testable.

---

## Project Structure

```
app/
  api/sales/route.ts        # API endpoint returning sales data
  dashboard/page.tsx        # Empty dashboard page composing the organism
  globals.css
  layout.tsx
  page.tsx                  # Landing page linking to /dashboard
src/
  components/
    atoms/                  # Buttons, Inputs, Selects
    molecules/              # ChartSwitcher, ThresholdFilter, YearSelect
    organisms/              # ChartBar, ChartLine, ChartPie, SalesExplorer
    templates/              # DashboardTemplate
  data/
    sales.ts                # Mock sales data & helpers
```

---

## Getting Started

### 1) Prerequisites
- **Node.js** 18+ (LTS recommended)
- **pnpm** or **npm** or **yarn**

### 2) Install
```bash
pnpm install
# or npm install
# or yarn
```

### 3) Run Dev Server
```bash
pnpm dev
# or npm run dev
# or yarn dev
```
Open http://localhost:3000 and navigate to **/dashboard**.

---

## Features Requested

- [x] **Next.js 15**, **TypeScript**, **Tailwind**
- [x] **Atomic structure** (atoms → molecules → organisms → templates)
- [x] **Multiple chart components** (Bar, Line, Pie) using **Recharts**
- [x] **Empty dashboard page** with an inserted organism component
- [x] **Mock data for 2022–2024** (inspired by Kaggle structures)
- [x] **Custom filter input** to set a minimum sales threshold
- [x] **Buttons** to switch between **bar / line / pie** charts
- [x] **README** with setup steps

### Enhancements
- [x] **API route** at `/api/sales?year=2024` that serves the mocked data
- [ ] Replace mock with **real API** (e.g. REST endpoint) and fetch in `SalesExplorer`
- [ ] Add **unit tests** for selectors & components
- [ ] Persist controls to URL params / localStorage

---

## Swapping to the API (optional)
Currently `SalesExplorer` reads from `src/data/sales`. To use the API instead, replace the data section:

```tsx
// inside SalesExplorer
useEffect(() => {
  async function load() {
    const res = await fetch(`/api/sales?year=${year}`);
    const json = await res.json();
    setData((json.data ?? []) as any[]);
  }
  load();
}, [year]);
```

---

## Styling
- **Tailwind** powers utility classes. See `app/globals.css` for a simple dark theme.
- Buttons/inputs are small, reusable **atoms**.

---

## Notes
- We pin `next` to `^15.0.0`. If your environment does not support v15 yet, use `"next": "latest"` in `package.json`.
- Recharts is dynamically imported to avoid SSR issues.
- The data is hard-coded but shaped like a Kaggle time‑series CSV (year, month, sales).

---

## What I Did
1. Bootstrapped Next.js 15 with TypeScript & Tailwind.
2. Implemented atomic structure: atoms, molecules, organisms, templates.
3. Built multiple chart components (Bar/Line/Pie) with switcher.
4. Added filters (year, threshold) and a dashboard page that composes them.
5. Created an API route as a stepping stone toward real data sources.
6. Wrote this README with setup and usage instructions.

---

## How to Deploy
You can deploy to **Vercel**:
- Create a new project, import your GitHub repo, and deploy with defaults.

---

## License
MIT
