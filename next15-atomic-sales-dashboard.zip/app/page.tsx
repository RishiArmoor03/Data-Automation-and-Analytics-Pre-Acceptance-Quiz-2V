import Link from "next/link";

export default function Home() {
  return (
    <section className="space-y-6">
      <div className="card p-6">
        <h2 className="text-2xl font-bold mb-2">Welcome</h2>
        <p className="text-white/80">
          This project demonstrates an atomic-structured Next.js 15 app with charts showing sales for 2022–2024.
        </p>
      </div>

      <Link href="/dashboard" className="btn-primary inline-block">
        Go to Dashboard
      </Link>
    </section>
  );
}
