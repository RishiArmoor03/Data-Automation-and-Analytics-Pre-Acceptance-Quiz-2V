import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Atomic Sales Dashboard",
  description: "Next.js 15 + Tailwind + Recharts demo using atomic design.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <header className="border-b border-white/10">
          <div className="container flex items-center gap-3 py-4">
            <div className="size-8 rounded-lg bg-brand-600" />
            <h1 className="text-xl font-semibold">Atomic Sales Dashboard</h1>
          </div>
        </header>
        <main className="container py-6">{children}</main>
        <footer className="container py-8 text-sm text-white/60">
          Built with Next.js 15, Tailwind, and Recharts — Atomic design (atoms → molecules → organisms → templates).
        </footer>
      </body>
    </html>
  );
}
