import dynamic from "next/dynamic";
import DashboardTemplate from "@/components/templates/DashboardTemplate";

// Dynamically import the client-only organism
const SalesExplorer = dynamic(() => import("@/components/organisms/SalesExplorer"), { ssr: false });

export default function DashboardPage() {
  return (
    <DashboardTemplate title="Sales Dashboard" subtitle="Explore yearly sales with filters & chart types">
      {/* Empty dashboard shell; organism is injected here */}
      <SalesExplorer />
    </DashboardTemplate>
  );
}
