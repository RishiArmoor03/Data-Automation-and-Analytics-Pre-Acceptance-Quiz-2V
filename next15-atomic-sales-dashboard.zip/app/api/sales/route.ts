import { NextResponse } from "next/server";
import { availableYears, salesByYear } from "@/data/sales";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const year = Number(searchParams.get("year"));
  const result = {
    years: availableYears(),
    data: Number.isFinite(year) ? salesByYear(year) : undefined,
  };
  return NextResponse.json(result);
}
